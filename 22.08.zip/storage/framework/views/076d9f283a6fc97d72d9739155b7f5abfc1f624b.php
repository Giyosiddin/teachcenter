

<?php $__env->startSection('content'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
      		<h1>Lessons</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Lessons</li>
            </ol>
          </div>
        </div>
        <?php if(session('msg')): ?>
          <div class="row justify-content-center">
            <div class="col-md-11">
              <div class="alert alert-success" role="alert">
                <?php echo e(session()->get('msg')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
            </div>
          </div>
        <?php endif; ?>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">lessons</h3>

          <div class="card-tools">
            <a href="<?php echo e(route('lesson.create')); ?>" class="btn btn-block btn-success btn-flat"> Add lesson</a>
          </div>
        </div>
        <div class="card-body p-0">
          <table class="table table-striped projects">
              <thead>
                  <tr>
                      <th style="width: 1%">
                          #
                      </th>
                      <th style="width: 20%">
                         lesson name
                      </th>
                      <th style="width: 20%">
                          Description
                      </th>
                      <th>
                          Course
                      </th>
                      <th>
                          Photo
                      </th>
                      <th style="width: 20%">
                      </th>
                  </tr>
              </thead>
              <tbody>
                  <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 
                  <tr>
                      <td>
                          #
                      </td>
                      <td>
                          <a>
                              <?php echo e($lesson->translation->title); ?>

                          </a>
                          <br/>
                          <small>
                              Created <?php echo e($lesson->created_at); ?>

                          </small>
                      </td>
                      <td class="project_progress">
                          <p>
                             <?php echo e($lesson->translation->description); ?>

                          </p>
                      </td>
                      <td class="project-state">
                        <?php if($lesson->course): ?>
                          <p><?php echo e($lesson->course->translation->title); ?></p>
                        <?php endif; ?>
                      </td>
                      <td class="project-state">
                        <img src="<?php echo e(\Storage::url($lesson->image)); ?>" alt="" width="100px">
                      </td>
                      <td class="project-actions text-right">
                          
                          <a class="btn btn-info btn-sm" href="<?php echo e(route('lesson.edit', $lesson->id)); ?>">
                              <i class="fas fa-pencil-alt">
                              </i>
                              Edit
                          </a>
                          <a class="btn btn-danger btn-sm" href="<?php echo e(route('lesson.delete', $lesson->id)); ?>">
                              <i class="fas fa-trash">
                              </i>
                              Delete
                          </a>
                      </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>
        </div>
        <!-- /.card-body -->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MySites\OSpanel_5_3_7\domains\teachcenter.lc\resources\views/admin/lesson/index.blade.php ENDPATH**/ ?>