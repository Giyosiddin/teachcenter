
<?php $__env->startSection('content'); ?>
    
    <!--====== PAGE BANNER PART START ======-->
    
    <section id="page-banner" class="pt-105 pb-130 bg_cover" data-overlay="8" style="background-image: url(<?php echo e(\Storage::url($page->image)); ?>)">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="page-banner-cont">
                        <h2><?php echo e($page->title_uz); ?></h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Asosiy sahifa</a></li>
                                <li class="breadcrumb-item active" aria-current="page"><?php echo e($page->title_uz); ?></li>
                            </ol>
                        </nav>
                    </div>  <!-- page banner cont -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>
    
    <!--====== PAGE BANNER PART ENDS ======-->
   
    <!--====== BLOG PART START ======-->
    
    <section id="blog-singel" class="pt-90 pb-120 gray-bg">
        <div class="container">
           <div class="row">
              <div class="col-lg-12">
                  <div class="blog-details mt-30">
                      <div class="thum">
                          <img src="<?php echo e(\Storage::url($page->image)); ?>" alt="Blog Details" width="100%">
                      </div>
                      <div class="cont">
                          <h3><?php echo e($page->title_uz); ?></h3>
                          <ul>
                               <li><a href="#"><i class="fa fa-calendar"></i> <?php echo e(date('d M Y', strtotime($page->updated_at))); ?></a></li>
                               
                           </ul>
                           <?php
                               echo $page->body_uz;
                           ?>
                           
                         
                      </div> <!-- cont -->
                      <div class="contact-from">
                        <div class="section-title">
                            <h5>Bog'lanish</h5>
                             <h2>
                                
                            <?php
                                if (\Request::path() == 'consalting')
                                    {
                                       echo "Konsalting xizmati uchun ariza jo'nating";
                                    }else{
                                        echo "Kursga yoziling";
                                    }
                            ?>
                           </h2>
                        </div> <!-- section title -->
                        <div class="main-form pt-45">
                            <form id="contact-form" action="<?php echo e(route('appels')); ?>" method="post" data-toggle="validator">
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="singel-form form-group">
                                            <input name="fullname" type="text" placeholder="I.F.Sh" data-error="Name is required." required="required">
                                            <div class="help-block with-errors"></div>
                                        </div> <!-- singel form -->
                                    </div>
                                    <div class="col-md-6">
                                        <div class="singel-form form-group">
                                            <input name="phone" type="text" placeholder="Telefon" data-error="Phone is required." required="required">
                                            <div class="help-block with-errors"></div>
                                        </div> <!-- singel form -->
                                    </div>
                                    <?php if(\Request::path() == 'consalting'): ?>
                                    <input type="hidden" name="type" value="consalting">
                                    <div class="col-md-6">
                                        <div class="singel-form form-group">
                                            <input name="country" type="text" placeholder="Qaysi davlat">
                                            <div class="help-block with-errors"></div>
                                        </div> <!-- singel form --> 
                                    </div>
                                    <?php else: ?>
                                    <input type="hidden" name="type" value="course">
                                    <div class="col-md-6">
                                        <div class="singel-form form-group">
                                            <input name="email" type="email" placeholder="Email" data-error="Valid email is required.">
                                            <div class="help-block with-errors"></div>
                                        </div> <!-- singel form -->
                                    </div>
                                    <?php endif; ?>
                                    <div class="col-md-6">
                                        <div class="singel-form form-group">
                                            <input name="direction" type="text" placeholder="Qaysi soha" data-error="" required="required">
                                            <div class="help-block with-errors"></div>
                                        </div> <!-- singel form --> 
                                    </div>
                                    <p class="form-message"></p>
                                    <div class="col-md-12">
                                        <div class="singel-form">
                                            <button type="submit" class="main-btn">Jo`natish</button>
                                        </div> <!-- singel form -->
                                    </div> 
                                </div> <!-- row -->
                            </form>
                        </div> <!-- main form -->
                    </div> <!--  contact from -->
                  </div> <!-- blog details -->
              </div>
           </div> <!-- row -->
        </div> <!-- container -->
    </section>
    
    <!--====== BLOG PART ENDS ======-->
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MySites\OSpanel_5_3_7\domains\teachcenter.lc\resources\views/pages/form-page.blade.php ENDPATH**/ ?>