
<?php $__env->startSection('content'); ?>
     
<section id="page-banner" class="pt-105 pb-110 bg_cover" data-overlay="8" style="background-image: url(<?php echo e(asset('front/images/page-banner-3.jpg')); ?>)">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="page-banner-cont">
                    <h2>Yangiliklar</h2>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Asosiy sahifa</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Yangiliklar</li>
                        </ol>
                    </nav>
                </div>  <!-- page banner cont -->
            </div>
        </div> <!-- row -->
    </div> <!-- container -->
</section>

<!--====== PAGE BANNER PART ENDS ======-->

<!--====== EVENTS PART START ======-->

<section id="event-page" class="pt-90 pb-120 gray-bg">
    <div class="container">
       <div class="row">
           <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="col-lg-6">
                <div class="singel-event-list mt-30">
                    <div class="event-thum">
                        <img src="<?php echo e(\Storage::url($post->image)); ?>" alt="<?php echo e($post->title_uz); ?>">
                    </div>
                    <div class="event-cont">
                        <span><i class="fa fa-calendar"></i> <?php echo e(date('d M Y', strtotime($post->updated_at))); ?></span>
                        <a href="<?php echo e(route('in.study-abroad', $post->slug)); ?>"><h4><?php echo e($post->title); ?></h4></a>
                        
                        
                        <p><?php echo e($post->excerpt_uz); ?></p>
                    </div>
                </div>
            </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       </div> <!-- row -->
        <div class="row">
            <div class="col-lg-12">
                <nav class="courses-pagination mt-50">
                    <?php echo e($posts->links()); ?>

                    
                </nav>  <!-- courses pagination -->
            </div>
        </div>  <!-- row -->
    </div> <!-- container -->
</section>

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MySites\OSpanel_5_3_7\domains\teachcenter.lc\resources\views/pages/news.blade.php ENDPATH**/ ?>