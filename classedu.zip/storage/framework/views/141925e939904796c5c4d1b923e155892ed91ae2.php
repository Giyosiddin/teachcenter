
<?php $__env->startSection('content'); ?>
    
    <!--====== PAGE BANNER PART START ======-->
    
    <section id="page-banner" class="pt-105 pb-130 bg_cover" data-overlay="8" style="background-image: url(<?php echo e(\Storage::url($post->image)); ?>)">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="page-banner-cont">
                        <h2><?php echo e($post->title_uz); ?></h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Asosiy sahifa</a></li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('news')); ?>">Yangiliklar</a></li>
                                <li class="breadcrumb-item active" aria-current="page"><?php echo e($post->title_uz); ?></li>
                            </ol>
                        </nav>
                    </div>  <!-- page banner cont -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>
    
    <!--====== PAGE BANNER PART ENDS ======-->
   
    <!--====== BLOG PART START ======-->
    
    <section id="blog-singel" class="pt-90 pb-120 gray-bg">
        <div class="container">
           <div class="row">
              <div class="col-lg-8">
                  <div class="blog-details mt-30">
                      <div class="thum">
                          <img src="<?php echo e(\Storage::url($post->image)); ?>" alt="Blog Details" width="100%">
                      </div>
                      <div class="cont">
                          <h3><?php echo e($post->title_uz); ?></h3>
                          <ul>
                               <li><a href="#"><i class="fa fa-calendar"></i> <?php echo e(date('d M Y', strtotime($post->updated_at))); ?></a></li>
                               
                           </ul>
                           <?php
                               echo $post->body_uz;
                           ?>
                           
                         
                      </div> <!-- cont -->
                  </div> <!-- blog details -->
              </div>
               <div class="col-lg-4">
                   <div class="saidbar">
                       <div class="row">
                           <div class="col-lg-12 col-md-6">
                               <div class="saidbar-search mt-30">
                                   <form action="#">
                                       <input type="text" placeholder="Search">
                                       <button type="button"><i class="fa fa-search"></i></button>
                                   </form>
                               </div> <!-- saidbar search -->
                               
                           </div> <!-- categories -->
                           <div class="col-lg-12 col-md-6">
                               <div class="saidbar-post mt-30">
                                   <h4>Yangiliklar</h4>
                                   <ul>
                                       <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <li>
                                            <a href="<?php echo e(route('in.news',$item->slug)); ?>">
                                                <div class="singel-post">
                                                   <div class="thum" style="float: inherit;padding-bottom: 20px;">
                                                       <img src="<?php echo e(\Storage::url($item->image)); ?>" width="100%" alt="Blog">
                                                   </div>
                                                   <div class="cont">
                                                       <h6><?php echo e($item->title_uz); ?></h6>
                                                       <span><?php echo e(date('d M Y', strtotime($post->updated_at))); ?></span>
                                                   </div>
                                               </div> <!-- singel post -->
                                            </a>
                                       </li>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </ul>
                               </div> <!-- saidbar post -->
                           </div>
                       </div> <!-- row -->
                   </div> <!-- saidbar -->
               </div>
           </div> <!-- row -->
        </div> <!-- container -->
    </section>
    
    <!--====== BLOG PART ENDS ======-->
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MySites\OSpanel_5_3_7\domains\teachcenter.lc\resources\views/pages/in_news.blade.php ENDPATH**/ ?>