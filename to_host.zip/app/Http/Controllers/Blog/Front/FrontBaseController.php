<?php

namespace App\Http\Controllers\Blog\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\Blog\BaseController;

class FrontBaseController extends BaseController
{
    //
}
