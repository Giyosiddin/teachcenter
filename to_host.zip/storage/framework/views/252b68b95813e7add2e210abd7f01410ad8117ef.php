<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <style>
        p {
            font-size: 14px;
        }

        .signature {
            font-style: italic;
        }
    </style>
</head>
<body>
    <p>Hey there <?php echo e($messages['name']); ?>,</p>
    <p>This is just a random email.</p>
    <p>Randomly,</p>
    <p class="signature">Dino Cajic</p>
</body>
</html><?php /**PATH D:\MySites\OSpanel_5_3_7\domains\teachcenter.lc\resources\views/emails/send-message.blade.php ENDPATH**/ ?>