

<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1> Edit lesson</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">Home</a></li>
              <li class="breadcrumb-item"><a href="<?php echo e(route('lesson.index')); ?>">Lesson</a></li>
              <li class="breadcrumb-item active">Edit lesson</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
  <section class="content">

    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <?php if(session('msg')): ?>
        <div class="row justify-content-center">
        <div class="col-md-11">
            <div class="alert alert-success" role="alert">
            <?php echo e(session()->get('msg')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
        </div>
        </div>
    <?php endif; ?>
	  <form action="<?php echo e(route('lesson.edit', $lesson->id)); ?>" method="POST" enctype="multipart/form-data">
     <?php echo csrf_field(); ?>
      <div class="row">
        <div class="col-md-9">
            <div class="card card-primary card-tabs">
              <div class="card-body">
                <div class="tab-content" id="custom-tabs-one-tabContent">
                  <div class="tab-pane fade show active" id="custom-tabs-one-home" role="tabpanel" aria-labelledby="custom-tabs-one-home-tab">
                     <div class="card-header">
                        <!-- <h3 class="card-title">Uzbekcha</h3> -->
                      </div>
                      <div class="card-body">
                        <div class="form-group">
                          <label for="inputName">Title</label>
                          <input type="text" required="required" value="<?php echo e($lesson->translation->title); ?>" id="title" required="required" name="title" class="form-control">
                        </div>
                        <div class="form-group">
                          <label for="inputDescription">Description</label>
                          <textarea id="inputDescription" class="form-control" name="description" rows="4"><?php echo e($lesson->translation->description); ?></textarea>
                        </div>
                        <div class="form-group">
                          <label for="inputBody">Body</label>
                          <textarea id="inputBody" class="form-control ckeditor" name="body" rows="4"><?php echo e($lesson->translation->body); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="video">Video link</label>
                            <input type="text" required="required" id="video" required="required" name="video" value="<?php echo e($lesson->video); ?>" class="form-control">
                          </div>
                      </div>
                  </div>
                </div>
              </div>
              <!-- /.card -->
            </div>
          <!-- /.card -->
        </div>
        <div class="col-md-3">
          <div class="card card-secondary">
            <div class="card-header">
              <h3 class="card-title">Others</h3>
            </div>
            <div class="card-body container">
              <div class="img"><a class=""><img src="<?php echo e(\Storage::url($lesson->image)); ?>" alt=""></a></div>
              <div class="form-group row" >
                <div class="dropzone col mt-2">
                  <div><i class="fas fa-plus"></i> <span>Photo</span></div>
                  <input type="file" name="image" id="image" class="form-control">
                  <input type="hidden" name="delete_image" id="delete_image" value="<?php if(!empty($lesson->image)): ?> <?php echo e($lesson->image); ?> <?php endif; ?>">
                </div>
                <div class="col mt-2 ">
                  <a href="#" class="btn btn-success w-100 pt-1 delete_file"><i class="fas fa-times"></i> <span>Delete</span></a>
                </div>
              </div>
              <div class="img"> <a class="file_name"><?php if(!is_null($lesson->file_first)): ?><i class="fas fa-file"></i>
              <span><?php echo e(basename(\Storage::url($lesson->file_first))); ?></span> <?php endif; ?></a> </div>
              <div class="form-group row">
                <div class="dropzone col mt-2"> <div><i class="fas fa-plus"></i> First file</div>
                  <input type="file" name="file_first" id="file_first" class="form-control" value="test">
                  <input type="hidden" name="delete_file_first" id="delete_file_first" value="<?php if(!empty($lesson->file_first)): ?> <?php echo e($lesson->file_first); ?> <?php endif; ?>">
                </div>
                <div class="col mt-2 ">
                  <a href="#" class="btn btn-success w-100 pt-1 delete_file"><i class="fas fa-times"></i><span>Delete</span></a>
                </div>
              </div>              
              <div class="img"> <a  class="file_name"><?php if(!is_null($lesson->file_second)): ?><i class="fas fa-file"></i>
                <span><?php echo e(basename(\Storage::url($lesson->file_second))); ?></span>  <?php endif; ?></a></div>
              <div class="form-group row">
                <div class="dropzone col mt-2 ">
                  <div><i class="fas fa-plus"></i> Second file</div>
                  <input type="file" name="file_second" value="<?php echo e(\Storage::path($lesson->file_second)); ?>" id="file_second" class="form-control">
                  <input type="hidden" name="delete_file_second" id="delete_file_second" value="<?php if(!empty($lesson->file_second)): ?><?php echo e($lesson->file_second); ?> <?php endif; ?>">
                </div>                
                <div class="col mt-2 ">
                  <a href="#" class="btn btn-success w-100 pt-1 delete_file"><i class="fas fa-times"></i><span>Delete</span></a>
                </div>
              </div>                            
              <div class="form-group">
                <label for="timeVideo">Time video</label>
                <input type="text" name="time" id="timeVideo" value="<?php echo e($lesson->time); ?>" class="form-control">
              </div>                            
              
              <div class="form-group">
                  <label>Course</label>
                  <select class="form-control select2" name="course_id" style="width: 100%;">
                    <option selected="selected">-- Choose course --</option>
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($course->id); ?>" <?php if($lesson->course_id == $course->id): ?> selected <?php endif; ?>><?php echo e($course->translation->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
              </div>              
              <div class="form-group">
                  <label>Language</label>
                  <select class="form-control select2" name="locale" style="width: 100%;">
                    <option selected="selected"> -- Choose language -- </option>
                    <option value="uz" <?php if($lesson->translation->locale == 'uz'): ?> selected <?php endif; ?>>Uz</option>
                    <option value="ru" <?php if($lesson->translation->locale == 'ru'): ?> selected <?php endif; ?>>Ru</option>
                    <option value="en" <?php if($lesson->translation->locale == 'en'): ?> selected <?php endif; ?>>En</option>
                  </select>
              </div>              
              <div class="form-group">
                <input type="submit" value="Save lesson" class="btn btn-success float-right">
              </div>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
      </div>
    </form>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MySites\OSpanel_5_3_7\domains\teachcenter.lc\resources\views/admin/lesson/edit.blade.php ENDPATH**/ ?>