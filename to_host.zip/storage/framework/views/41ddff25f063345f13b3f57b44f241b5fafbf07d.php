

<?php $__env->startSection('content'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
      		<h1>Appels</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(route('admin.index')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Appels</li>
            </ol>
          </div>
        </div>
        <?php if(session('msg')): ?>
          <div class="row justify-content-center">
            <div class="col-md-11">
              <div class="alert alert-success" role="alert">
                <?php echo e(session()->get('msg')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
            </div>
          </div>
        <?php endif; ?>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Appels</h3>

          <div class="card-tools">
            <ul class="nav nav-tabs" id="for-course-tab" role="tablist">
                <li class="nav-item">
                  <a class="nav-link active" id="for-consaltion-tab" data-toggle="pill" href="#for-consaltion" role="tab" aria-controls="for-consaltion" aria-selected="true">For consaltiong</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" id="for-course-tab" data-toggle="pill" href="#for-course" role="tab" aria-controls="for-course" aria-selected="false">For course</a>
                </li>
              </ul>
          </div>
        </div>
        <div class="card-body p-0">
            <div class="tab-content" id="custom-tabs-one-tabContent">
                <div class="tab-pane fade show active" id="for-consalting" role="tabpanel" aria-labelledby="for-consalting-tab">
                    <table class="table table-striped projects">
                        <thead>
                            <tr>
                                <th style="width: 1%">
                                    #
                                </th>
                                <th style="width: 20%">
                                    Full name
                                </th>
                                <th style="width: 18%" class="text-center">
                                    Phone
                                </th>
                                <th style="width: 20%">
                                    Country
                                </th>
                                <th>
                                   Direction
                                </th>                                
                                <th>
                                    Date
                                 </th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $appels_consalting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    #
                                </td>
                                <td>
                                    <a>
                                        <?php echo e($appel->fullname); ?>

                                    </a>
                                </td>
                                <td class="project-state">
                                    <?php echo e($appel->phone); ?>

                                </td>
                                <td>
                                    <div>
                                        <strong><?php echo e($appel->country); ?></strong>
                                    </div>
                                </td>
                                <td class="project_progress">
                                    <p style="max-width: 500px">
                                    <?php echo e($appel->direction); ?>

                                    </p>
                                </td>
                                <td class="project-actions ">
                                    Created <?php echo e($appel->created_at); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="tab-pane fade" id="for-course" role="tabpanel" aria-labelledby="for-course-tab">
                    <table class="table table-striped projects">
                        <thead>
                            <tr>
                                <th style="width: 1%">
                                    #
                                </th>
                                <th style="width: 20%">
                                    Full name
                                </th>
                                <th style="width: 18%" class="text-center">
                                    Phone
                                </th>
                                <th style="width: 20%">
                                    Email
                                </th>
                                <th>
                                   Direction
                                </th>                                
                                <th>
                                    Date
                                 </th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $appels_course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appel_course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    #
                                </td>
                                <td>
                                    <a>
                                        <?php echo e($appel_course->fullname); ?>

                                    </a>
                                </td>
                                <td class="project-state">
                                    <?php echo e($appel_course->phone); ?>

                                </td>
                                <td>
                                    <div>
                                        <strong><?php echo e($appel_course->email); ?></strong>
                                    </div>
                                </td>
                                <td class="project_progress">
                                    <p style="max-width: 500px">
                                    <?php echo e($appel_course->direction); ?>

                                    </p>
                                </td>
                                <td class="project-actions">
                                    Created <?php echo e($appel_course->created_at); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                
            </div>
        </div>
        <!-- /.card-body -->
      </div>
      <!-- /.card -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MySites\OSpanel_5_3_7\domains\teachcenter.lc\resources\views/admin/appels.blade.php ENDPATH**/ ?>